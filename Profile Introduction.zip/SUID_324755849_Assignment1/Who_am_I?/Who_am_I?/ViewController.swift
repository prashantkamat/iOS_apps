//
//  ViewController.swift
//  Who_am_I?
//
//  Created by Vishvesh Shah on 2/8/18.
//  Copyright © 2018 Prashant Kamat. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myDescription: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //Pop Up Alert
    @IBAction func showAlert(){
        let alert = UIAlertController(title: "Contact Details",
                                      message: "Email : ppkamat@syr.edu",
            preferredStyle: .alert  )
        
        let action = UIAlertAction( title: "Thank You!",
            style: .default,
            handler: nil
        )
        
        alert.addAction(action)
        present(alert, animated: true, completion: nil)
    }
    
    //Change Font
    @IBAction func changeFont(){
        myDescription.font = UIFont(name:"Times New Roman", size: 20.0)
        myDescription.textColor = UIColor.blue
    }
}

