//
//  ViewController.swift
//  DiceGameApp
//
//  Created by Vishvesh Shah on 2/22/18.
//  Copyright © 2018 Prashant Kamat. All rights reserved.
//  Thursday Feb 22 2018

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var playerImage: UIImageView!
    @IBOutlet weak var computerImage: UIImageView!
    
    @IBOutlet weak var currentRound: UILabel!
    
    @IBOutlet weak var playerScore: UILabel!
    @IBOutlet weak var computerScore: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    var currentRoundCount : UInt32 = 0
    var plScore : UInt32 = 0
    var compScore : UInt32 = 0
    var result : UInt32 = 0
    
    var plTurn : UInt32 = 0
    var compTurn : UInt32 = 0
    
 
    
    @IBAction func rollTheDice(_ sender: UIButton) {
        
        // generate random number
        plTurn = arc4random_uniform(6) + 1
        compTurn = arc4random_uniform(6) + 1
        
        // assign images
        playerImage.image = UIImage(named : "Dice\(plTurn)")
        computerImage.image = UIImage(named : "Dice\(compTurn)")
        
        // generate new round and scores
        currentRoundCount = currentRoundCount + 1
        plScore = plScore + plTurn
        compScore = compScore + compTurn
        
        currentRound.text = "ROUND : \(currentRoundCount)"
        playerScore.text = "Player Score : \(plScore)"
        computerScore.text = "Computer Score : \(compScore)"
        
        // when round is 3
        
        if(currentRoundCount == 3)
        {
            if (plScore > compScore){ result = 1}
            else if (plScore < compScore){ result = 2}
            calcResult()
        }
        
    }
    
    // calc Result
    func calcResult()
    {
        switch result
        {
        case 1 : // player Wins
            
            let actionAlert = UIAlertController( title : "Congratulations !! " , message : "You Win !! ", preferredStyle: .alert )
            actionAlert.addAction(UIAlertAction(title: "Play Again", style: .default, handler:{ action in self.resetGame()}))
            actionAlert.addAction(UIAlertAction(title: "Exit", style: .default, handler:{ action in self.exitGame()}))
            present(actionAlert, animated: true, completion: nil)
            
        case 2:
            
            let actionAlert = UIAlertController( title : " Oops !! " , message : "You lose !! ", preferredStyle: .alert )
            actionAlert.addAction(UIAlertAction(title: "Play Again", style: .default, handler:{ action in self.resetGame()}))
            actionAlert.addAction(UIAlertAction(title: "Exit", style: .default, handler:{ action in self.exitGame()}))
            present(actionAlert, animated: true, completion: nil)
            
        default:
            let actionAlert = UIAlertController( title : " Wow !! " , message : "Its a Tie !!", preferredStyle: .alert )
            actionAlert.addAction(UIAlertAction(title: "Play Again", style: .default, handler:{ action in self.resetGame()}))
            actionAlert.addAction(UIAlertAction(title: "Exit", style: .default, handler:{ action in self.exitGame()}))
            present(actionAlert, animated: true, completion: nil)
        }
        
        
        
    }

    @IBAction func resetButton(_ sender: Any) {
        resetGame()
    }
    
    func resetGame(){
        currentRoundCount = 0
        plScore  = 0
        compScore  = 0
        result  = 0
        plTurn  = 0
        compTurn  = 0
        
        currentRound.text = "LET'S BEGIN"
        playerScore.text = "Player Score : \(plScore)"
        computerScore.text = "Computer Score : \(compScore)"
        
        playerImage.image = UIImage(named : "Roll")
        computerImage.image = UIImage(named : "Roll")
    }
    
    func exitGame()
    {
            currentRound.text = "THANK YOU !!"
        
    }
}
    
    
    


