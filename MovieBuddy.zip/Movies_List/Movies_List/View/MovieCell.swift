//
//  MovieCell.swift
//  Movies_List
//
//  Created by Vishvesh Shah on 3/20/18.
//  Copyright © 2018 Prashant Kamat. All rights reserved.
//

import Foundation
import UIKit

let imageCache=NSCache<NSString,AnyObject>()
extension UIImageView{
    
    func downloadedFrom(url: URL, contentMode mode: UIViewContentMode = .scaleAspectFit) {
        contentMode = mode
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
                else { return }
            DispatchQueue.main.async() {
                self.image = image
            }
            }.resume()
    }
    
    func downloadedFrom(link: String, contentMode mode: UIViewContentMode = .scaleAspectFit) {
        guard let url = URL(string: link) else { return }
        downloadedFrom(url: url, contentMode: mode)
    }
    
    func downloadimageUsingcacheWithLink(_ urlLink: String){
        self.image=nil
        if urlLink.isEmpty{
            return
        }
        if let cachedImage=imageCache.object(forKey: urlLink as NSString)as? UIImage{
            self.image=cachedImage
            return
        }
        let url=URL(string:urlLink)
        URLSession.shared.dataTask(with: url!,completionHandler:{(data,response,error) in
            if let err=error{
                print("The error is:",err)
                return
            }
            DispatchQueue.main.async {
                if let newImage=UIImage(data:data!){
                    
                    imageCache.setObject(newImage, forKey: urlLink as NSString)
                    self.image=newImage
                }
            }
        }).resume()
    }
    
}

class MovieCell: UITableViewCell{
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setUpViews()
    }
    
    var movie: MovieData?
    
    let nameLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    let thumbnailImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.backgroundColor = UIColor.blue
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        return imageView
    }()
    
    let imageCache=NSCache<NSString,AnyObject>()
    
    let seperatorView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.black
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    func setUpViews()
    {
        addSubview(nameLabel)
        addSubview(thumbnailImageView)
        addSubview(seperatorView)
        
        thumbnailImageView.frame = CGRect(x: 20, y: 20, width: 100, height: 100)
        
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-16-[v1]-16-[v0(80)]-16-|", options: NSLayoutFormatOptions(), metrics: nil, views: ["v0": nameLabel, "v1" : thumbnailImageView]))
        
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat : "V:|-50-[v0]-50-|", options: NSLayoutFormatOptions(), metrics: nil, views: ["v0": nameLabel]))
        
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat : "V:|-50-[v0]-50-|", options: NSLayoutFormatOptions(), metrics: nil, views: ["v0": thumbnailImageView]))
        
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat : "H:|[v0]|", options: NSLayoutFormatOptions(), metrics: nil, views: ["v0": seperatorView]))
        
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat : "V:|[v0(1)]", options: NSLayoutFormatOptions(), metrics: nil, views: ["v0": seperatorView]))
        
        thumbnailImageView.frame = CGRect(x: 20, y: 20, width: 100, height: 100)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
}




