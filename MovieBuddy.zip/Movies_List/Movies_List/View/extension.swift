//
//  extension.swift
//  Movies_List
//
//  Created by Vishvesh Shah on 3/21/18.
//  Copyright © 2018 Prashant Kamat. All rights reserved.
//

import Foundation
