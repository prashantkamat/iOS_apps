//
//  Detail.swift
//  Movies_List
//
//  Created by Vishvesh Shah on 3/21/18.
//  Copyright © 2018 Prashant Kamat. All rights reserved.
//

import Foundation
import UIKit




class nameMovie : UIView
{
    var movie: MovieData?
    
    let textView: UITextView = {
        let tv = UITextView()
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.allowsEditingTextAttributes = false
        tv.textAlignment = .center
        tv.textColor = UIColor.blue
        tv.isEditable = false
        tv.font = UIFont.systemFont(ofSize: 30.0)
        tv.text = "SAMPLE DESCRIPTION"
        return tv
    }()
    
    func setupViews()
    {
        addSubview(textView)
        
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-8-[v0]-8-|", options: NSLayoutFormatOptions(), metrics: nil, views: ["v0": textView]))
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-4-[v0]-4-|", options: NSLayoutFormatOptions(), metrics: nil, views: ["v0": textView]))
    }
}

class ReleaseDate : UIView
{
    var movie: MovieData?
    
    /*let releaseView: UITextView = {
        let rv = UITextView()
        rv.translatesAutoresizingMaskIntoConstraints = false
        rv.allowsEditingTextAttributes = false
        //rv.textAlignment = .center
        rv.textColor = UIColor.black
        rv.isEditable = false
        rv.font = UIFont.systemFont(ofSize: 15.0)
        rv.text = "RELEASED ON : "
        return rv
    }()*/
    
    let textView: UITextView = {
        let tv = UITextView()
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.allowsEditingTextAttributes = false
        //tv.textAlignment = .center
        tv.textColor = UIColor.black
        tv.isEditable = false
        tv.font = UIFont.systemFont(ofSize: 15.0)
        tv.text = "SAMPLE DESCRIPTION"
        return tv
    }()
    
    func setupViews()
    {
        //addSubview(releaseView)
        addSubview(textView)
        
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-8-[v0]-8-|", options: NSLayoutFormatOptions(), metrics: nil, views: ["v0": textView]))
    
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-4-[v0]-4-|", options: NSLayoutFormatOptions(), metrics: nil, views: ["v0": textView]))

    }
}



class DetailDescription : UIView
{
    var movie: MovieData?
   
  /*  let descView: UITextView = {
        let dv = UITextView()
        dv.translatesAutoresizingMaskIntoConstraints = false
        dv.allowsEditingTextAttributes = false
        dv.font = UIFont.systemFont(ofSize: 15.0)
        dv.text = "DESCRIPTION"
        return dv
    }() */
    
    let textView: UITextView = {
        let tv = UITextView()
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.allowsEditingTextAttributes = false
        tv.isEditable = false
        tv.font = UIFont.systemFont(ofSize: 15.0)
        tv.text = "SAMPLE DESCRIPTION"
        return tv
    }()
    
    let dividerLineView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = UIColor.clear
        return view
    }()
    
    func setupViews(){
       // addSubview(descView)
        addSubview(textView)
        addSubview(dividerLineView)
        
      //  addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-2-[v0]-2-|", options: NSLayoutFormatOptions(), metrics: nil, views: ["v0": descView]))
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-8-[v0]-8-|", options: NSLayoutFormatOptions(), metrics: nil, views: ["v0": textView]))
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-14-[v0]|", options: NSLayoutFormatOptions(), metrics: nil, views: ["v0": dividerLineView]))
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-4-[v0]-4-[v1(1)]|", options: NSLayoutFormatOptions(), metrics: nil, views: ["v0": textView, "v1": dividerLineView]))
        
    }
}


class PosterCell: UICollectionViewCell, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout{
    
    var movie: MovieData?
    private let cellId = "moviecellId"
    var results: MovieResults?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 4
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell =  collectionView.dequeueReusableCell(withReuseIdentifier: cellId, for: indexPath) as! cellMovie
        let posterPathLink = "http://image.tmdb.org/t/p/w92" + (movie?.posterPath)!
        let backdropPathLink = "http://image.tmdb.org/t/p/w92" + (movie?.backdrop)!
        
        if (indexPath.item/2 == 0)
        {cell.imageView.downloadimageUsingcacheWithLink(posterPathLink)}
        else if (indexPath.item/2 == 1)
        {cell.imageView.downloadimageUsingcacheWithLink(backdropPathLink)}
        print(indexPath.item/2)
        return cell
        
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width : 299 , height: 130)
    }
    
    
    
    
    
    let movieCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.minimumInteritemSpacing = 10
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.backgroundColor = UIColor.clear
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        return collectionView
    }()
    
    func setupViews()
    {
        backgroundColor = UIColor.clear
        addSubview(movieCollectionView)
        movieCollectionView.delegate = self
        movieCollectionView.dataSource = self
        movieCollectionView.register(cellMovie.self, forCellWithReuseIdentifier: cellId)
        
        //add Constraints
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-10-[v0]-10-|", options: NSLayoutFormatOptions(), metrics: nil, views: ["v0": movieCollectionView]))
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-10-[v0]-10-|", options: NSLayoutFormatOptions(), metrics: nil, views: ["v0": movieCollectionView]))
        
    }
}

class cellMovie: UICollectionViewCell{
    
    var movie: MovieData?
    var results: MovieResults?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    let imageView: UIImageView = {
        
        let iv = UIImageView()
        //iv.image = UIImage(named: "blackpanther")
        iv.contentMode = .scaleAspectFill
        iv.clipsToBounds = true
        return iv
    }()
    
    func setupViews(){
        backgroundColor = UIColor.red
        addSubview(imageView)
        imageView.frame = CGRect(x:0, y:0, width:frame.width, height:frame.width)
    }
}


