//
//  ViewController.swift
//  Movies_List
//
//  Created by Vishvesh Shah on 3/20/18.
//  Copyright © 2018 Prashant Kamat. All rights reserved.
//

import UIKit

class MyTableViewController: UITableViewController {

    var movie: MovieData?
    var results: MovieResults?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
       downloadJSON {
            print("JSON downloaded succesful")
            self.tableView.reloadData()
        }
        
        navigationItem.title = "Popular Movies"
        tableView.register(MovieCell.self, forCellReuseIdentifier: "cellId")
    }
    
    // ---- Downloads the JSON data from the API------- //
    func downloadJSON(completed: @escaping () -> () ){
        let url = URL(string: "http://api.themoviedb.org/3/movie/popular?api_key=c42e7197f84e328d0701c8745a31e3b7")
        
        
        URLSession.shared.dataTask(with: (url)!){ (data, response, err) in
            if err == nil {
                // CHeck JSON Downloaded data
                guard let jsondata = data else { return }
                do{
                    self.results = try JSONDecoder().decode(MovieResults.self, from: jsondata)
                    DispatchQueue.main.async{
                        completed()
                    }
                    print(jsondata)
                }catch{
                    print("JSON downloading error!")
                }
            }
            
        }.resume()
    }

    // ----- END JSON ---------------
    
    // ---- returns the number of rows -------- //
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if let number = results?.movies.count{
            return number
        }
        return 0
    }
    

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let movie=results?.movies[indexPath.row]
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cellId", for: indexPath)
            cell.textLabel?.text=movie.title
            cell.detailTextLabel?.textColor = .black
            let posterPathLink = "http://image.tmdb.org/t/p/w92" + (movie.posterPath)!
            cell.imageView?.downloadimageUsingcacheWithLink(posterPathLink)
            return cell
        
       /* return tableView.dequeueReusableCell(withIdentifier: "cellId", for: indexPath) */
        }
        return UITableViewCell()
    }
    
    
    // Create an action to call the detailViewController
    
    func showDetailOfMovie(movie: MovieInfo){

     let detailController = DetailViewController()
     detailController.movie = movie
     navigationController?.pushViewController(detailController, animated: true)
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let movie = results?.movies[indexPath.row]{
            self.showDetailOfMovie(movie: movie)
        }
    }
    
    // Delete a movie from list
    
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            tableView.beginUpdates()
            results?.movies.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
            tableView.endUpdates()
        }
    }
    
 /* override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
*/

}



