//
//  DetailViewController.swift
//  Movies_List
//
//  Created by Vishvesh Shah on 3/21/18.
//  Copyright © 2018 Prashant Kamat. All rights reserved.
//

import Foundation
import UIKit

class DetailViewController: UIViewController {
    
    var movieDetail: MovieData?
    
    var movie: MovieInfo? {
        didSet{
            let id = movie?.id
            // print(id!)
            
            let link = "http://api.themoviedb.org/3/movie/\(id!)?api_key=c42e7197f84e328d0701c8745a31e3b7"
            //print(urlLink!)
            
            let url = URL(string: link) // convert URL to String
            
            URLSession.shared.dataTask(with: url!){ (data, response, err) in
                if err == nil {
                    //Check Downloaded JSON data
                    guard let jsondata = data else { return }
                    
                    do{
                        self.movieDetail = try JSONDecoder().decode(MovieData.self, from: jsondata)
                        DispatchQueue.main.async{
                            self.setupViews()
                        }
                    }catch{
                        print("JSON Downloading Error")
                    }
                }
                
            }.resume()
        }
        
    }
    
    let overview: DetailDescription = {
        let overview = DetailDescription()
        return overview
    }()
    
    let titleM: nameMovie = {
        let title = nameMovie()
        return title
    }()
    
    let poster: PosterCell = {
        let poster = PosterCell()
        return poster
    }()
    
    let movieRating: CosmosView = {
        let cosmos = CosmosView()
        return cosmos
    }()
    
    let movieRelease: ReleaseDate = {
        let rdate = ReleaseDate()
        return rdate
    }()
    
    
    func setupViews()
    {
        view.backgroundColor = UIColor.white
        
        titleM.movie = movieDetail
        view.addSubview(titleM)
        titleM.translatesAutoresizingMaskIntoConstraints = false
        titleM.textView.text = movieDetail?.title
        titleM.setupViews()
        titleM.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor).isActive = true
        titleM.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor).isActive = true
        titleM.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor, multiplier: 0.1).isActive = true
        titleM.widthAnchor.constraint(equalTo: view.safeAreaLayoutGuide.widthAnchor).isActive = true
        
        movieRelease.movie = movieDetail
        view.addSubview(movieRelease)
        movieRelease.translatesAutoresizingMaskIntoConstraints = false
        movieRelease.textView.text = movieDetail?.releaseDate
        movieRelease.textView.textAlignment = .center
        movieRelease.setupViews()
        movieRelease.topAnchor.constraint(equalTo: titleM.bottomAnchor).isActive = true
        movieRelease.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor).isActive = true
        movieRelease.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor, multiplier: 0.1).isActive = true
        movieRelease.widthAnchor.constraint(equalTo: view.safeAreaLayoutGuide.widthAnchor).isActive = true
        
        
        view.addSubview(poster)
        poster.movie = movieDetail
        poster.translatesAutoresizingMaskIntoConstraints = false
        //poster.movieCollectionView.backgroundColor = UIColor.red
        poster.setupViews()
        //Add Collection View constraints
        poster.topAnchor.constraint(equalTo: movieRelease.bottomAnchor, constant: 20).isActive = true
        poster.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor).isActive = true
        poster.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor, multiplier: 0.3).isActive = true
        poster.widthAnchor.constraint(equalTo: view.safeAreaLayoutGuide.widthAnchor).isActive = true
        
        overview.movie = movieDetail
        view.addSubview(overview)
        overview.translatesAutoresizingMaskIntoConstraints = false
        overview.textView.text = movieDetail?.overview
        overview.textView.isEditable = false
        overview.setupViews()
        overview.topAnchor.constraint(equalTo: poster.bottomAnchor, constant: 10).isActive = true
        overview.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor).isActive = true
        overview.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor, multiplier: 0.3).isActive = true
        overview.widthAnchor.constraint(equalTo: view.safeAreaLayoutGuide.widthAnchor).isActive = true
        overview.backgroundColor = .white
        
        // Change the cosmos view rating
        
        movieRating.translatesAutoresizingMaskIntoConstraints = false
        var rate: Double
        rate = ((movieDetail?.rating)!/2.0)
        movieRating.rating = rate
        print(movieRating.rating)
        movieRating.settings.fillMode = .precise
        view.addSubview(movieRating)
        movieRating.topAnchor.constraint(equalTo: overview.bottomAnchor, constant: 10).isActive = true
        movieRating.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor).isActive = true
        movieRating.heightAnchor.constraint(equalTo:view.safeAreaLayoutGuide.heightAnchor, multiplier: 0.01).isActive = true
        movieRating.widthAnchor.constraint(equalTo: view.safeAreaLayoutGuide.widthAnchor).isActive = true
        
    }
    
    private let cellId = "cellId"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        setupViews()
        
    }
}
