//
//  Movie.swift
//  Movies_List
//
//  Created by Vishvesh Shah on 3/21/18.
//  Copyright © 2018 Prashant Kamat. All rights reserved.
//

import Foundation
import UIKit

struct MovieData: Decodable
{
    let id: Int?
    let posterPath: String?
    let backdrop: String?
    let title: String?
    let releaseDate: String?
    let rating: Double?
    let overview: String?
    let genres: [MovieGenre]
    
    private enum CodingKeys: String, CodingKey{
        case id, posterPath = "poster_path", backdrop = "backdrop_path",title, releaseDate = "release_date", rating = "vote_average",overview,genres
    }
}

struct MovieGenre: Decodable{
    let id: Int?
    let name: String?
}

struct MovieInfo: Decodable{
    let id: Int?
    let posterPath: String?
    let backdrop: String?
    let title: String?
    
    private enum CodingKeys: String, CodingKey{
        case id, posterPath = "poster_path", title, backdrop = "backdrop_path"
    }
}

struct MovieResults: Decodable{
    let page: Int?
    let numResults: Int?
    let numPages: Int?
    var movies: [MovieInfo]
    
    private enum CodingKeys: String, CodingKey{
        case page, numResults = "total_results", numPages = "total_pages",
        movies = "results"
    }
}
